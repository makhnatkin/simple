export const ShopHeader = ({ children }) =>
    <header className="shop-header">
        Меню:
        {children}
    </header>
